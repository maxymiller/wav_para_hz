wavin="in"
wavout="out"

shhome="$PWD"

sample_rate=44100
channels=1
bits=8

janela_ms=10

fft_nperseg=441
fft_overlap=220

awk_hz_max=1200.00

# python
python_janela_ms=100
python_overlap=50
#python_limiar=5.0
#python_limiar=1.0
python_limiar=0.5
#python_limiar=0.1
python_top_n=5
python_tolerancia_hz=30
