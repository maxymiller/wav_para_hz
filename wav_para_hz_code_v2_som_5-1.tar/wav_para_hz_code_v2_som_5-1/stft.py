#!/usr/bin/env python3

import sys
import numpy as np

from scipy.io import wavfile
from scipy.signal import stft, istft


if len(sys.argv) < 5:
    print("Uso:")
    print("python3 stft.py entrada.wav notas.txt grub.txt saida.wav")
    sys.exit(1)


arquivo_wav = sys.argv[1]
arquivo_notas = sys.argv[2]
arquivo_grub = sys.argv[3]
arquivo_saida = sys.argv[4] + ".wav"
awk_hz_max = sys.argv[10]


# Configuração
JANELA_MS = 10       # tamanho da janela em ms
OVERLAP = 50         # porcentagem de sobreposição
LIMIAR = 5.0
TOP_N = 1

if len(sys.argv) >= 9:
    JANELA_MS = float(sys.argv[5])
    OVERLAP = float(sys.argv[6])
    LIMIAR = float(sys.argv[7])
    TOP_N = int(sys.argv[8])


# Ler WAV
fs, audio = wavfile.read(arquivo_wav)

#tipo_original = audio.dtype


# Se estéreo, usa mono
if audio.ndim > 1:
    audio = audio[:, 0]


# Converter para float
audio_float = audio.astype(np.float32)

# Remove o nível DC
audio_float -= np.mean(audio_float)


# calcula tamanho da janela
JANELA = max(32, int(fs * (JANELA_MS / 1000)))

sobreposicao = int(JANELA * OVERLAP / 100)

if sobreposicao >= JANELA:
    sobreposicao = JANELA - 1


print("Sample rate:", fs)
print("Janela:", JANELA, "amostras")

print("som:", int(sys.argv[8]), " (top som)")
print("Tolerância:", int(sys.argv[9]), "Hz (Tolerância para considerar que é o mesmo som)")

print("awk_hz_max:", awk_hz_max, "hz")


# STFT
freqs, tempos, Zxx = stft(
    audio_float,
    fs=fs,
    window="hann",
    nperseg=JANELA,
    noverlap=sobreposicao
)

# Rastreamento dos sons
sons = [[] for _ in range(TOP_N)]

# Tolerância para considerar que é o mesmo som
TOLERANCIA_HZ = 30
if len(sys.argv) >= 10:
    TOLERANCIA_HZ = int(sys.argv[9])

tempo_bloco = 0.0
if len(tempos) > 1:
    tempo_bloco = tempos[1] - tempos[0]

# Salvar frequências
with open(arquivo_notas, "w") as notas:

    notas.write(f"# Sample Rate: {fs}\n")
    notas.write(f"# Janela (ms): {JANELA_MS}\n")
    notas.write(f"# Janela (amostras): {JANELA}\n")
    notas.write(f"# Overlap: {OVERLAP}%\n")
    notas.write(f"# Limiar: {LIMIAR}\n\n")

    for tempo_i, tempo in enumerate(tempos):

        notas.write(f"Tempo={tempo:.4f}s\n")

        amplitudes = np.abs(Zxx[:, tempo_i])
        fases = np.angle(Zxx[:, tempo_i])


        for f, amp, fase in zip(freqs, amplitudes, fases):

            if amp >= LIMIAR:
                notas.write(
                    f"{f:.2f}Hz "
                    f"amp={amp:.4f} "
                    f"fase={fase:.4f}\n"
                )

        notas.write("\n")


# Frequência principal para GRUB
with open(arquivo_grub, "w") as grub:

    grub.write(f"# tempo_bloco={tempo_bloco:.6f}\n")
    grub.write(f"# top_n={TOP_N}\n")
    grub.write(f"# awk_hz_max={awk_hz_max}\n")

    frequencias_anteriores = [None] * TOP_N

    for i in range(len(tempos)):

        amp = np.abs(Zxx[:, i])

        # Ignora 0 Hz
        amp[0] = 0

        # Encontra candidatos acima do limiar
        candidatos = []

        for indice in range(1, len(freqs) - 1):

            if amp[indice] < LIMIAR:
                continue

            # Pico local
            if amp[indice] >= amp[indice - 1] and \
               amp[indice] >= amp[indice + 1]:

                candidatos.append(indice)

        # Ordena pelos mais fortes
        candidatos.sort(
            key=lambda x: amp[x],
            reverse=True
        )

        # Limita a TOP_N candidatos
        candidatos = candidatos[:TOP_N]

        frequencias_atual = [None] * TOP_N

        # Primeiro tenta manter os sons anteriores
        usados = set()

        for slot in range(TOP_N):

            freq_anterior = frequencias_anteriores[slot]

            if freq_anterior is None:
                continue

            melhor = None
            melhor_distancia = TOLERANCIA_HZ

            for indice in candidatos:

                if indice in usados:
                    continue

                freq = freqs[indice]
                distancia = abs(freq - freq_anterior)

                if distancia <= melhor_distancia:
                    melhor = indice
                    melhor_distancia = distancia

            if melhor is not None:

                frequencias_atual[slot] = freqs[melhor]
                usados.add(melhor)

        # Preenche os slots vazios com novos sons
        for indice in candidatos:

            if indice in usados:
                continue

            for slot in range(TOP_N):

                if frequencias_atual[slot] is None:

                    frequencias_atual[slot] = freqs[indice]
                    usados.add(indice)
                    break

        # Salva a janela
        for slot in range(TOP_N):

            if frequencias_atual[slot] is None:
                grub.write("0.00 ")
            else:
                grub.write(
                    f"{frequencias_atual[slot]:.2f} "
                )

        grub.write("\n")

        frequencias_anteriores = frequencias_atual


# Reconstruir áudio
_, audio_out = istft(
    Zxx,
    fs=fs,
    window="hann",
    nperseg=JANELA,
    noverlap=sobreposicao
)


# Normalizar
#audio_out = np.clip(audio_out, -32768, 32767)


# Salvar WAV 16 bits
#audio_out = audio_out.astype(np.int16)

# Normaliza para o intervalo [-1, 1]
maximo = np.max(np.abs(audio_out))
if maximo > 0:
    audio_out /= maximo

# Converte para int16
audio_out = (audio_out * 32767).astype(np.int16)


wavfile.write(
    arquivo_saida,
    fs,
    audio_out
)


print("Concluído!")
print("Notas :", arquivo_notas)
print("GRUB  :", arquivo_grub)
print("WAV   :", arquivo_saida)
print("Tempo por bloco:", tempo_bloco)
print("Quantidade de blocos:", len(tempos))
print("Duração estimada:", len(tempos) * tempo_bloco)
print("Duração original:", len(audio_float) / fs)
