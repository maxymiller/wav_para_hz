#!/bin/bash
error() {
	echo "[$0] error: $1"
	exit 1
}
./main.sh || error "main.sh"
./notas_para_grub.sh || error "notas_para_grub.sh"
./notas_para_wav.sh || error "notas_para_wav.sh"
