#!/bin/bash

source config.sh

error() {
	echo "[$0] error: $1"
	exit 1
}

rm -r "$wavout/ffmpeq/" "$wavout/grub/"
mkdir -p "$wavout"
mkdir -p "$wavout/ffmpeq" "$wavout/notas" "$wavout/grub" "$wavout/wav" "$wavout/log"

find "$wavin/" -type f | while read -r arquivo
do

nome=$(basename "$arquivo")
nome="${nome%.*}"

echo "Convertendo \"$arquivo\""

ffmpeg -nostdin -y \
-i "$arquivo" \
-vn \
-ar "$sample_rate" \
-ac "$channels" \
-c:a pcm_u8 \
"$wavout/ffmpeq/$nome-ffmpeg.wav" 2> "$wavout/log/${nome}-ffmpeg.txt" || error "ffmpeq"

echo "[$0] config:"
echo "[$0] ffmpeg: $wavout/ffmpeq/$nome-ffmpeg.wav"
echo "[$0] notas: $wavout/notas/$nome-notas.txt"
echo "[$0] grub: $wavout/grub/$nome-grub.txt"
echo "[$0] out dir: $wavout/wav/$nome-out"

python3 stft.py \
"$wavout/ffmpeq/$nome-ffmpeg.wav" \
"$wavout/notas/$nome-notas.txt" \
"$wavout/grub/$nome-grub.txt" \
"$wavout/wav/$nome-out" \
"$python_janela_ms" \
"$python_overlap" \
"$python_limiar" \
"$python_top_n" \
"$python_tolerancia_hz" \
"$awk_hz_max" || error "stft.py"

done
