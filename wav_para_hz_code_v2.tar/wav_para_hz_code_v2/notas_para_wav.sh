#!/bin/bash
#
# notas_para_wav.sh
#
# Gera um arquivo WAV simulando os beeps a partir do arquivo
# *-notas2.txt usando o SoX.
#
# Cada frequência é sintetizada como uma onda quadrada e, ao final,
# todas as partes são unidas em um único arquivo WAV.
#
# Desenvolvimento:
# - Primeiras versões desenvolvidas com auxílio do ChatGPT e Gemini.
# - Testes e experimentos adicionais realizados com Manus.
#
# Histórico:
# - wav_para_hz.sh: primeira versão do conversor de áudio para frequência.
# - wav_para_hz2.sh: segunda versão com melhorias.
# - Experimentos posteriores: geração de GRUB_INIT_TUNE,
#   WAV de beep e visualização das notas.
#

wavoutconfig=work
wavoutconfig_new=out

maxconfig=3

error() {
	echo "[$0] error: $1"
	exit 1
}

if [ -e "$wavoutconfig/tmp" ]; then
	rm -r "$wavoutconfig/tmp"
fi
if [ -e "$wavoutconfig/block" ]; then
	rm -r "$wavoutconfig/block"
fi

rm -r "$wavoutconfig/wav/"
mkdir -p "$wavoutconfig/wav"

find "$wavoutconfig/notas2/" -type f -name "*-notas2.txt" | while read -r arquivo
do

mkdir -p "$wavoutconfig/tmp"
mkdir -p "$wavoutconfig/block"

nome=$(basename "$arquivo")
nome="${nome%-notas2.*}"

tempo_bloco=$(
    awk -F= '/^# tempo_bloco=/{print $2}' \
    "$wavoutconfig_new/grub/${nome}-grub.txt"
)

echo "[$0] tempo_bloco: $tempo_bloco s"

echo "[$0]: \"$nome\"..."
echo "[$0] (1/$maxconfig): Sintetizando fatias de áudio em onda quadrada..."
loop=0
while read -r freq dur; do
    tempo=$(awk "BEGIN {print $dur * $tempo_bloco}") || error "$wavoutconfig_new/grub/${nome}-grub.txt"
    
    if [ "$freq" -lt 40 ]; then
        sox -n "$wavoutconfig/tmp/$loop.wav" trim 0 "$tempo" || error "sox"
    else
        sox -n "$wavoutconfig/tmp/$loop.wav" synth "$tempo" square "$freq" || error "sox"
    fi
    ((loop++))
done < "$wavoutconfig/notas2/${nome}-notas2.txt"

echo "[$0] (2/$maxconfig): Concatenando blocos temporários..."
loop2=0
for ((i=0; i<loop; i++)); do
    if [ "$i" == "$((999+(loop2*1000)))" ]; then
        out="sox"
        for j in {0..999}; do
            out="$out $wavoutconfig/tmp/$(($j+(loop2*1000))).wav"
        done
        out="$out $wavoutconfig/block/$loop2.wav"
        $out || error "sox"
        loop2=$((loop2+1))
    fi
    if [ "$i" == "$((loop-1))" ]; then
        out="sox"
        calc=$((loop2*1000))
        for ((j=calc; j<loop; j++)); do
            out="$out $wavoutconfig/tmp/$j.wav"
        done
        out="$out $wavoutconfig/block/$loop2.wav"
        $out || error "sox"
    fi
done

echo "[$0] (3/$maxconfig): Unindo áudio final..."
sox $(find "$wavoutconfig/block/" -type f -name "*.wav" | sort -V) "$wavoutconfig/wav/${nome}-out.wav"

#echo "[$0] \"$wavoutconfig_new/wav/${nome}-out.wav\":  $(soxi -D "$wavoutconfig_new/wav/${nome}-out.wav")"
#echo "[$0] \"$wavoutconfig/wav/${nome}-out.wav\": $(soxi -D "$wavoutconfig/wav/${nome}-out.wav")"

if [ -f "$wavout_new/wav/${nome}-out.wav" ]; then
    echo "[$0] \"$wavout_new/wav/${nome}-out.wav\": $(soxi -D "$wavout_new/wav/${nome}-out.wav")"
else
    echo "[$0] \"$wavout_new/wav/${nome}-out.wav\": não existe"
fi

if [ -f "$wavoutconfig/wav/${nome}-out.wav" ]; then
    echo "[$0] \"$wavoutconfig/wav/${nome}-out.wav\": $(soxi -D "$wavoutconfig/wav/${nome}-out.wav")"
fi

rm -r "$wavoutconfig/tmp"
rm -r "$wavoutconfig/block"

done
