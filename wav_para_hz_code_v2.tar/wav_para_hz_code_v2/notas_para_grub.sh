#!/bin/bash
#
# notas_para_grub.sh
#
# Converte o arquivo *-grub.txt gerado pelo stft.py para o formato
# GRUB_INIT_TUNE, agrupando notas consecutivas para reduzir a quantidade
# de comandos.
#
# Desenvolvimento:
# - Primeiras versões desenvolvidas com auxílio do ChatGPT e Gemini.
# - Testes e experimentos adicionais realizados com Manus.
#
# Histórico:
# - wav_para_hz.sh: primeira versão do conversor de áudio para frequência.
# - wav_para_hz2.sh: segunda versão com melhorias.
# - Experimentos posteriores: geração de GRUB_INIT_TUNE,
#   WAV de beep e visualização das notas.
#

wavoutconfig=work
wavoutconfig_new=out
maxconfig=5

error() {
	echo "[$0] error: $1"
	exit 1
}

rm -r "$wavoutconfig/notas2/" "$wavoutconfig/notas3/" "$wavoutconfig/grub/"
mkdir -p "$wavoutconfig"

mkdir -p "$wavoutconfig/notas" "$wavoutconfig/notas2" "$wavoutconfig/notas3" "$wavoutconfig/grub"

find "$wavoutconfig_new/grub/" -type f -name "*-grub.txt" | while read -r arquivo
do

nome=$(basename "$arquivo")
nome="${nome%-grub.*}"

top_n=$(
    awk -F= '/^# top_n=/{print $2}' \
    "$wavoutconfig_new/grub/${nome}-grub.txt"
)

echo "[$0] top_n: $top_n som"

#rm "$wavoutconfig/notas/${nome}-notas.txt"
#rm "$wavoutconfig/notas2/${nome}-notas2.txt"

echo "[$0] (1/$maxconfig): Agrupando notas consecutivas \"${nome}-notas.txt\"..."
awk '
/^# top_n=/ {
    split($2, a, "=")
    top_n = a[2]
}
/^# awk_hz_max=/ {
    split($2, a, "=")
    awk_hz_max = a[2]
}
/^#/ {
    next
}

{
    if (!inicio) {
        som_n=1
        limiar=0.00
    }
    loop=0
    s=0.00
    while (loop < top_n && s <= limiar || loop < top_n && s > awk_hz_max) {
        coluna = ((som_n - 1) % top_n) + 1
        s = $coluna
        som_n++
        if(som_n > top_n) {
            som_n=1
        }
        
        loop++
    }
    if (s > awk_hz_max) {
        s = 0.00
    }

    if (!inicio) {
        f = s
        d = 1
        inicio = 1
        next
    }

    if (s == f) {
        d++
    } else {
        print f, d
        f = s
        d = 1
    }
}

END {
    if (inicio)
        print f, d
}
' "$wavoutconfig_new/grub/${nome}-grub.txt" > "$wavoutconfig/notas/${nome}-notas.txt" || error "awk"

echo "[$0] (2/$maxconfig): Agrupando notas consecutivas \"${nome}-notas2.txt\"..."
awk '
/^# top_n=/ {
    split($2, a, "=")
    top_n = a[2]
}
/^# awk_hz_max=/ {
    split($2, a, "=")
    awk_hz_max = int(a[2])
}
/^#/ {
    next
}

{
    if (!inicio) {
        som_n=1
        limiar=0
    }
    loop=0
    s=0
    while (loop < top_n && s <= limiar || loop < top_n && s > awk_hz_max) {
        coluna = ((som_n - 1) % top_n) + 1
        s = int($coluna)
        som_n++
        if(som_n > top_n) {
            som_n=1
        }
        
        loop++
    }
    if (s > awk_hz_max) {
        s = 0
    }

    if (!inicio) {
        f = s
        d = 1
        inicio = 1
        next
    }

    if (s == f) {
        d++
    } else {
        print f, d
        f = s
        d = 1
    }
}

END {
    if (inicio)
        print f, d
}
' "$wavoutconfig_new/grub/${nome}-grub.txt" > "$wavoutconfig/notas2/${nome}-notas2.txt" || error "awk"

echo "[$0] (3/$maxconfig): Agrupando notas consecutivas \"${nome}-notas3.txt\"..."

echo "# nome=$nome" > "$wavoutconfig/notas3/${nome}-notas3.txt"
grep "# tempo_bloco=" "$wavoutconfig_new/grub/${nome}-grub.txt" >> "$wavoutconfig/notas3/${nome}-notas3.txt"
grep "# top_n=" "$wavoutconfig_new/grub/${nome}-grub.txt" >> "$wavoutconfig/notas3/${nome}-notas3.txt"
grep "# awk_hz_max=" "$wavoutconfig_new/grub/${nome}-grub.txt" >> "$wavoutconfig/notas3/${nome}-notas3.txt"

awk '
/^# top_n=/ {
    split($2, a, "=")
    top_n = a[2]
}
/^# awk_hz_max=/ {
    split($2, a, "=")
    awk_hz_max = int(a[2])
}
/^#/ {
    next
}

{
    if (!inicio) {
        som_n=1
        limiar=0
    }
    loop=0
    s=0
    while (loop < top_n && s <= limiar || loop < top_n && s > awk_hz_max) {
        coluna = ((som_n - 1) % top_n) + 1
        s = int($coluna)
        som_n++
        if(som_n > top_n) {
            som_n=1
        }
        
        loop++
    }
    if (s > awk_hz_max) {
        s = 0
    }

    if (!inicio) {
        f = s
        d = 1
        inicio = 1
        next
    }

    if (s == f) {
        d++
    } else {
        print f, d
        f = s
        d = 1
    }
}

END {
    if (inicio)
        print f, d
}
' "$wavoutconfig_new/grub/${nome}-grub.txt" >> "$wavoutconfig/notas3/${nome}-notas3.txt" || error "awk"

echo "[$0] (4/$maxconfig): Gerando \"${nome}-grub.txt\"..."
grub_str="GRUB_INIT_TUNE=\"1200"
while read -r freq dur; do
    grub_str="$grub_str $freq $dur"
done < "$wavoutconfig/notas2/${nome}-notas2.txt" || error "awk"
grub_str="$grub_str\""
echo "$grub_str" > "$wavoutconfig/grub/${nome}-grub.txt"

done
echo "[$0]: pasta \"$wavoutconfig\""
echo "[$0] (5/$maxconfig): Processo concluído com sucesso!"
echo "Ficheiros gerados em $wavoutconfig/:"
echo " - grub.txt"
echo " - notas.txt"
echo " - notas2.txt"
echo " - notas3.txt"
